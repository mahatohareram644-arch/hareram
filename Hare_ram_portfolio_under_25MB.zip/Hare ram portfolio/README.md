# Contemporary Editorial Portfolio for Hare Ram Mahato

A modern, expressive, editorial-style personal portfolio website built with **React**, **TypeScript**, **Tailwind CSS**, and **Motion for React** (`framer-motion`).

Designed with an original visual identity far removed from dark minimalist or monochrome templates:
- **Warm Off-White Base**: `#F8F7F2`
- **Deep Navy Text**: `#172033`
- **Electric Purple Accent**: `#7957FF`
- **Vibrant Coral Highlight**: `#FF725E`
- **Fresh Lime Pop**: `#D9F36A`
- **Soft Lavender Tints**: `#F3F0FC`

---

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Start Development Server
```bash
npm run dev
```
Open your browser at `http://localhost:5173`.

### 3. Build for Production
```bash
npm run build
```

---

## 🛠️ How to Customize Personal Information

All personal details, skills, featured projects, and journey milestones are centralized in a single configuration file:
👉 **`src/data/portfolio.ts`**

You do **not** need to touch any UI components to update information.

### 1. Update Name, Role & Bio
Open `src/data/portfolio.ts` and modify the `personal` object:
```typescript
personal: {
  name: "Hare Ram Mahato", // Brother's real name
  role: "Full-Stack Software Engineer", // His role
  eyebrow: "Creative Frontend & Web Developer",
  tagline: "I Build Things for the Web.",
  shortBio: "Crafting expressive, high-performance web applications...",
  location: "Bangalore, India", // or remote location
  email: "your.brother@example.com",
  github: "https://github.com/username",
  linkedin: "https://linkedin.com/in/username",
  // ...
}
```

### 2. Update Skills & Capabilities
Edit the `skills` array in `src/data/portfolio.ts`:
```typescript
skills: [
  { name: "TypeScript", category: "languages", level: "Core" },
  { name: "React", category: "frontend", level: "Core" },
  { name: "Node.js", category: "backend", level: "Advanced" },
  { name: "PostgreSQL", category: "backend", level: "Working Knowledge" },
  // ...
]
```
Categories supported:
- `'languages'` (Programming Languages)
- `'frontend'` (Frontend Frameworks & Libraries)
- `'backend'` (Backend & Databases)
- `'tools'` (Developer Tooling & DevOps)
- `'design'` (Design & UI/UX Tools)

### 3. Update Featured Projects
Edit the `projects` array in `src/data/portfolio.ts`:
```typescript
projects: [
  {
    id: "my-project",
    title: "Real Project Name",
    tagline: "One line summary of the project",
    description: "In-depth description of what this project does and why it was built.",
    category: "Full Stack", // 'Full Stack' | 'Frontend' | 'Tools & Systems'
    featured: true,
    accent: "purple", // 'purple' | 'coral' | 'lime' | 'navy'
    tags: ["React", "TypeScript", "Tailwind CSS"],
    metrics: ["10k+ Monthly Users", "99.9% Uptime"],
    links: {
      liveUrl: "https://my-live-demo.com", // Set to null if not deployed yet
      githubUrl: "https://github.com/username/project",
      caseStudyUrl: "#"
    },
    caseStudy: {
      challenge: "The specific architectural or design problem faced...",
      solution: "How it was engineered and resolved...",
      keyFeatures: ["Feature 1", "Feature 2"],
      architectureNotes: ["Note 1", "Note 2"]
    },
    isPlaceholder: false
  }
]
```

### 4. Update Career & Education Journey
Edit the `journey` array in `src/data/portfolio.ts`:
```typescript
journey: [
  {
    id: "journey-1",
    type: "experience", // 'experience' | 'education' | 'milestone'
    period: "2023 — Present",
    title: "Software Engineer",
    organization: "Company Name",
    location: "City, Country",
    description: "Key responsibilities and engineering accomplishments...",
    highlights: ["Led frontend architecture...", "Reduced bundle size by 35%"],
    tags: ["React", "TypeScript", "Next.js"],
    isPlaceholder: false
  }
]
```

---

## 📬 Contact Form Configuration

The portfolio supports three flexible, production-ready dispatch modes in `src/data/portfolio.ts` under `personal.contactConfig`:

### Mode A: `mailto` (Default — Zero Setup Required)
```typescript
contactConfig: {
  mode: 'mailto',
  recipientEmail: "your.brother@example.com",
}
```
When submitted, it automatically creates a pre-filled email in the visitor's email client. Honest, transparent, and works with no external accounts needed.

### Mode B: Formspree (Direct Background Sending)
1. Sign up for free at [formspree.io](https://formspree.io)
2. Create a form and copy your form ID (e.g. `xpwzaoqk`)
3. Update `src/data/portfolio.ts`:
```typescript
contactConfig: {
  mode: 'formspree',
  formspreeId: "xpwzaoqk",
  recipientEmail: "your.brother@example.com",
}
```

### Mode C: Web3Forms (Access Key)
1. Generate an access key at [web3forms.com](https://web3forms.com)
2. Update `src/data/portfolio.ts`:
```typescript
contactConfig: {
  mode: 'web3forms',
  web3formsAccessKey: "YOUR-WEB3FORMS-ACCESS-KEY",
  recipientEmail: "your.brother@example.com",
}
```

---

## 🌐 Deployment Instructions

### Deploy to Vercel (Recommended)
1. Push this repository to GitHub.
2. Sign in to [Vercel](https://vercel.com).
3. Click **"Add New..."** → **"Project"** and import this repository.
4. Framework preset: **Vite** (detected automatically).
5. Build command: `npm run build`
6. Output directory: `dist`
7. Click **Deploy**.

### Deploy to Netlify
1. Sign in to [Netlify](https://www.netlify.com).
2. Click **"Add new site"** → **"Import an existing project"**.
3. Select your GitHub repository.
4. Set build command: `npm run build`
5. Set publish directory: `dist`
6. Click **Deploy Site**.

---

## 📂 Project Architecture

```
src/
├── components/
│   ├── Navbar.tsx         # Responsive navbar with active section indicator & mobile drawer
│   ├── Hero.tsx           # Expressive opening hero, availability pill, interactive card
│   ├── About.tsx          # Biography, creative portrait frame, quick facts, motto
│   ├── Skills.tsx         # Filterable skill cards with categories & tags
│   ├── Projects.tsx       # Centerpiece gallery with asymmetric cards & live demo states
│   ├── ProjectModal.tsx   # Detailed case study modal with architecture highlights
│   ├── Journey.tsx        # Career, education, and milestones visual timeline
│   ├── Contact.tsx        # Bold contact section, email copy, validated form
│   └── Footer.tsx         # Editorial sign-off, back to top button, social links
├── data/
│   └── portfolio.ts       # Central source of truth for all data & config
├── types/
│   └── portfolio.ts       # Strict TypeScript interfaces
├── hooks/
│   └── useActiveSection.ts # Scroll spy hook for navigation highlighting
├── App.tsx                # Main root component
├── main.tsx               # Entry point
└── index.css              # Custom styling, fonts, and paper textures
```

