import { Transition, Variants } from 'framer-motion';

export const smoothTransition: Transition = {
  duration: 0.65,
  ease: [0.22, 1, 0.36, 1],
};

export const springTransition: Transition = {
  type: 'spring',
  stiffness: 350,
  damping: 28,
};

export const drawerVariants: Variants = {
  closed: {
    x: '100%',
    transition: {
      type: 'spring',
      damping: 30,
      stiffness: 300,
    },
  },
  open: {
    x: 0,
    transition: {
      type: 'spring',
      damping: 25,
      stiffness: 220,
      staggerChildren: 0.05,
      delayChildren: 0.1,
    },
  },
};

export const itemVariants: Variants = {
  closed: { opacity: 0, x: 20 },
  open: { opacity: 1, x: 0 },
};

