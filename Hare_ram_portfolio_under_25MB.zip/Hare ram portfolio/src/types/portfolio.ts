export type SkillCategory = 'languages' | 'frontend' | 'backend' | 'design' | 'tools';

export interface Skill {
  name: string;
  category: SkillCategory;
  level?: 'Core' | 'Advanced' | 'Working Knowledge' | 'Currently Exploring';
  iconName?: string;
}

export type ProjectCategory = 'All' | 'Full Stack' | 'Frontend' | 'Creative & UI' | 'Tools & Systems';

export interface ProjectCaseStudy {
  challenge: string;
  solution: string;
  keyFeatures: string[];
  architectureNotes?: string[];
}

export interface Project {
  id: string;
  title: string;
  tagline: string;
  description: string;
  category: 'Full Stack' | 'Frontend' | 'Creative & UI' | 'Tools & Systems';
  featured: boolean;
  accent: 'purple' | 'coral' | 'lime' | 'navy';
  tags: string[];
  metrics?: string[];
  links: {
    liveUrl?: string | null;
    githubUrl?: string | null;
    caseStudyUrl?: string | null;
  };
  caseStudy?: ProjectCaseStudy;
  isPlaceholder?: boolean;
}

export type JourneyType = 'experience' | 'education' | 'milestone';

export interface JourneyItem {
  id: string;
  type: JourneyType;
  period: string;
  title: string;
  organization: string;
  location?: string;
  description: string;
  highlights?: string[];
  tags?: string[];
  isPlaceholder?: boolean;
}

export interface PersonalDetails {
  name: string;
  pronouns?: string;
  role: string;
  eyebrow: string;
  tagline: string;
  shortBio: string;
  aboutParagraphs: string[];
  personalMotto: string;
  location: string;
  availability: {
    status: 'Available' | 'Busy' | 'Open to Discussion';
    label: string;
    sublabel: string;
  };
  email: string;
  github: string;
  linkedin: string;
  twitter?: string;
  resumeUrl?: string;
  avatarUrl?: string;
  quickFacts: Array<{
    label: string;
    value: string;
    highlight?: boolean;
  }>;
  interests: string[];
  contactConfig: {
    /**
     * Choose how form submissions are handled:
     * - 'mailto': Direct client-side email link with prefilled subject/body (Default zero-config)
     * - 'formspree': Send via Formspree API (Provide formspreeId)
     * - 'web3forms': Send via Web3Forms API (Provide web3formsAccessKey)
     */
    mode: 'mailto' | 'formspree' | 'web3forms';
    formspreeId?: string; // e.g. "xpwzaoqk"
    web3formsAccessKey?: string; // e.g. "YOUR-ACCESS-KEY"
    recipientEmail: string;
    noticeText?: string;
  };
}

export interface PortfolioData {
  personal: PersonalDetails;
  skills: Skill[];
  projects: Project[];
  journey: JourneyItem[];
}

