import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ExternalLink, Github, CheckCircle, Cpu, AlertCircle } from 'lucide-react';
import { Project } from '../types/portfolio';

interface ProjectModalProps {
  project: Project | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (project) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [project, onClose]);

  if (!project) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 lg:p-8">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-navy-900/70 backdrop-blur-sm"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 24 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 24 }}
          transition={{ type: 'spring', damping: 26, stiffness: 320 }}
          className="relative z-10 w-full max-w-3xl max-h-[88vh] sm:max-h-[90vh] overflow-y-auto bg-cream-50 rounded-3xl border-3 border-navy-900 shadow-brutal-lg p-4 sm:p-7 flex flex-col"
        >
          {/* Header Bar */}
          <div className="flex items-start justify-between gap-3 pb-3 sm:pb-4 border-b-2 border-navy-900/10 mb-4 sm:mb-6">
            <div className="min-w-0 pr-2">
              <div className="flex flex-wrap items-center gap-1.5 mb-1.5">
                <span className="px-2 py-0.5 rounded-full bg-purple-soft text-purple-electric border border-purple-electric/30 font-mono text-[10px] sm:text-xs font-bold uppercase tracking-wider">
                  {project.category}
                </span>
                {project.isPlaceholder && (
                  <span className="px-2 py-0.5 rounded-full bg-lime-soft text-navy-800 border border-navy-900/20 font-mono text-[10px] sm:text-xs font-bold">
                    Customizable
                  </span>
                )}
              </div>
              <h2 className="font-display font-extrabold text-xl sm:text-3xl text-navy-900 leading-tight">
                {project.title}
              </h2>
              <p className="text-xs sm:text-sm text-navy-600 font-medium mt-1 line-clamp-2">
                {project.tagline}
              </p>
            </div>

            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={onClose}
              className="min-w-[40px] min-h-[40px] sm:min-w-[44px] sm:min-h-[44px] flex items-center justify-center rounded-2xl bg-white border-2 border-navy-900 shadow-brutal-sm text-navy-900 hover:bg-cream-200 transition-colors shrink-0"
              aria-label="Close Case Study"
            >
              <X className="w-5 h-5" />
            </motion.button>
          </div>

          {/* Project Summary */}
          <div className="mb-4 sm:mb-6 p-3.5 sm:p-4 rounded-2xl bg-white border-2 border-navy-900 shadow-brutal-sm">
            <h3 className="text-[10px] sm:text-xs font-mono font-bold uppercase tracking-wider text-navy-500 mb-1.5">
              Overview
            </h3>
            <p className="text-navy-800 leading-relaxed text-xs sm:text-sm lg:text-base">
              {project.description}
            </p>
          </div>

          {/* Detailed Case Study (if available) */}
          {project.caseStudy && (
            <div className="space-y-4 sm:space-y-6">
              {/* Challenge & Solution Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
                <div className="p-3.5 sm:p-4 rounded-2xl bg-coral-soft border-2 border-navy-900">
                  <h4 className="flex items-center gap-1.5 font-display font-bold text-xs sm:text-sm text-coral mb-1.5">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>The Challenge</span>
                  </h4>
                  <p className="text-xs sm:text-sm text-navy-800 leading-relaxed">
                    {project.caseStudy.challenge}
                  </p>
                </div>

                <div className="p-3.5 sm:p-4 rounded-2xl bg-lime-soft border-2 border-navy-900">
                  <h4 className="flex items-center gap-1.5 font-display font-bold text-xs sm:text-sm text-navy-900 mb-1.5">
                    <CheckCircle className="w-4 h-4 text-[#10B981] shrink-0" />
                    <span>The Solution</span>
                  </h4>
                  <p className="text-xs sm:text-sm text-navy-800 leading-relaxed">
                    {project.caseStudy.solution}
                  </p>
                </div>
              </div>

              {/* Key Features */}
              {project.caseStudy.keyFeatures && (
                <div className="p-4 sm:p-5 rounded-2xl bg-white border-2 border-navy-900">
                  <h4 className="font-display font-bold text-xs sm:text-sm text-navy-900 mb-2.5 flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-purple-electric shrink-0" />
                    <span>Key Features & Innovations</span>
                  </h4>
                  <ul className="space-y-2">
                    {project.caseStudy.keyFeatures.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-navy-800">
                        <span className="w-1.5 h-1.5 rounded-full bg-purple-electric mt-1.5 shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Architecture Notes */}
              {project.caseStudy.architectureNotes && (
                <div className="p-4 sm:p-5 rounded-2xl bg-purple-soft/60 border-2 border-navy-900">
                  <h4 className="font-display font-bold text-xs sm:text-sm text-navy-900 mb-2">
                    Architecture & Implementation Highlights
                  </h4>
                  <ul className="space-y-1">
                    {project.caseStudy.architectureNotes.map((note, idx) => (
                      <li key={idx} className="text-[11px] sm:text-xs text-navy-700 font-mono">
                        → {note}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* Tech Tags */}
          <div className="mt-4 sm:mt-6 pt-4 sm:pt-6 border-t-2 border-navy-900/10">
            <h4 className="text-[10px] sm:text-xs font-mono font-bold uppercase tracking-wider text-navy-500 mb-2 sm:mb-3">
              Technologies Used
            </h4>
            <div className="flex flex-wrap gap-1.5 sm:gap-2">
              {project.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-2.5 py-0.5 sm:px-3 sm:py-1 rounded-xl bg-white text-[11px] sm:text-xs font-bold text-navy-900 border-2 border-navy-900 shadow-brutal-sm"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {/* Action Links */}
          <div className="mt-6 pt-4 sm:pt-6 border-t-2 border-navy-900/10 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              {project.links.liveUrl ? (
                <motion.a
                  whileTap={{ scale: 0.96 }}
                  href={project.links.liveUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-lime-accent hover:bg-lime-hover text-navy-900 text-xs sm:text-sm font-bold rounded-xl border-2 border-navy-900 shadow-brutal-sm transition-all"
                >
                  <span>Launch Live Demo</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </motion.a>
              ) : (
                <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-cream-200 text-navy-500 text-[11px] font-mono border border-navy-900/20">
                  <span>Demo in portfolio.ts</span>
                </span>
              )}

              {project.links.githubUrl && (
                <motion.a
                  whileTap={{ scale: 0.96 }}
                  href={project.links.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-cream-200 text-navy-900 text-xs sm:text-sm font-bold rounded-xl border-2 border-navy-900 shadow-brutal-sm transition-all"
                >
                  <Github className="w-3.5 h-3.5" />
                  <span>GitHub</span>
                </motion.a>
              )}
            </div>

            <button
              onClick={onClose}
              className="px-3 py-1.5 text-xs font-bold text-navy-600 hover:text-navy-900"
            >
              Close
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
