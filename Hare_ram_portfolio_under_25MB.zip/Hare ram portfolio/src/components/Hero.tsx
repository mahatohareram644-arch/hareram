import React from 'react';
import { motion } from 'framer-motion';
import { ArrowDown, ArrowUpRight, Sparkles, Terminal, Code2, Layers, CheckCircle2 } from 'lucide-react';
import { PersonalDetails } from '../types/portfolio';
import { smoothTransition } from '../utils/motion';

interface HeroProps {
  personal: PersonalDetails;
}

export const Hero: React.FC<HeroProps> = ({ personal }) => {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const isMobile = window.innerWidth < 768;
      const navOffset = isMobile ? 68 : 84;
      const elPos = el.getBoundingClientRect().top + window.scrollY;
      window.scrollTo({
        top: elPos - navOffset,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-[90vh] pt-24 pb-12 sm:pt-32 sm:pb-20 lg:pt-36 lg:pb-24 flex flex-col justify-between overflow-hidden bg-paper-texture"
    >
      {/* Decorative background ambient glows */}
      <div className="absolute top-16 right-5 sm:right-10 w-60 sm:w-80 h-60 sm:h-80 rounded-full bg-purple-soft/70 blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-10 left-5 sm:left-10 w-64 sm:w-96 h-64 sm:h-96 rounded-full bg-coral-soft/60 blur-3xl pointer-events-none -z-10" />
      <div className="absolute top-1/2 left-1/4 w-48 sm:w-64 h-48 sm:h-64 rounded-full bg-lime-soft/70 blur-3xl pointer-events-none -z-10" />

      {/* Floating rotating stamp (desktop only) */}
      <div className="hidden xl:block absolute top-36 left-8 pointer-events-none">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 24, repeat: Infinity, ease: 'linear' }}
          className="w-16 h-16 rounded-full border-2 border-dashed border-navy-900/30 flex items-center justify-center text-xs font-mono font-bold text-navy-600 select-none"
        >
          ✦ DEV ✦
        </motion.div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full my-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          
          {/* Left Column: Expressive Editorial Copy */}
          <div className="lg:col-span-7 flex flex-col items-start">
            
            {/* Animated Availability Pill */}
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ ...smoothTransition, delay: 0.05 }}
              className="inline-flex items-center gap-2.5 px-3 sm:px-3.5 py-1.5 rounded-full bg-white border-2 border-navy-900 shadow-brutal-sm mb-5 sm:mb-6"
            >
              <span className="relative flex h-2.5 w-2.5 sm:h-3 sm:w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-lime-accent opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 sm:h-3 sm:w-3 bg-[#10B981]"></span>
              </span>
              <span className="text-xs sm:text-sm font-bold text-navy-900 truncate max-w-[240px] sm:max-w-none">
                {personal.availability.label}
              </span>
            </motion.div>

            {/* Oversized Expressive Headline with Fluid Typography */}
            <motion.h1
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ ...smoothTransition, delay: 0.15 }}
              className="font-display font-extrabold text-3xl sm:text-5xl md:text-6xl lg:text-7xl tracking-tight text-navy-900 leading-[1.12] sm:leading-[1.08] mb-5 sm:mb-6"
            >
              Hello, I'm{' '}
              <span className="relative inline-block text-purple-electric whitespace-nowrap">
                <span className="relative z-10">{personal.name}</span>
                <motion.span 
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ duration: 0.6, delay: 0.45, ease: 'easeOut' }}
                  className="absolute -bottom-1 left-0 right-0 h-2.5 sm:h-3.5 bg-lime-accent -z-0 rounded-sm -rotate-1 origin-left"
                />
              </span>
              .<br />
              <span className="font-editorial-serif font-normal italic text-navy-900 text-2xl sm:text-4xl md:text-5xl lg:text-6xl tracking-normal">
                I build things
              </span>{' '}
              for the web.
            </motion.h1>

            {/* Short Introduction */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ ...smoothTransition, delay: 0.25 }}
              className="text-sm sm:text-base lg:text-lg text-navy-700 leading-relaxed max-w-2xl mb-7 sm:mb-8"
            >
              {personal.shortBio}
            </motion.p>

            {/* Primary & Secondary Call to Actions */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ ...smoothTransition, delay: 0.35 }}
              className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 w-full sm:w-auto"
            >
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => scrollTo('projects')}
                className="group min-h-[48px] inline-flex items-center justify-center gap-2.5 px-6 sm:px-7 py-3.5 bg-purple-electric hover:bg-purple-hover text-white text-sm sm:text-base font-bold rounded-2xl border-2 border-navy-900 shadow-brutal hover:shadow-brutal-lg transition-all"
              >
                <span>Explore My Work</span>
                <ArrowDown className="w-4 h-4 sm:w-5 sm:h-5 group-hover:translate-y-1 transition-transform" />
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => scrollTo('contact')}
                className="group min-h-[48px] inline-flex items-center justify-center gap-2.5 px-5 sm:px-6 py-3.5 bg-white hover:bg-coral-soft text-navy-900 text-sm sm:text-base font-bold rounded-2xl border-2 border-navy-900 shadow-brutal hover:shadow-brutal-coral transition-all"
              >
                <span>Let's Connect</span>
                <ArrowUpRight className="w-4 h-4 sm:w-5 sm:h-5 text-coral group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </motion.button>
            </motion.div>

            {/* Quick Mini Badges */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ ...smoothTransition, delay: 0.45 }}
              className="flex flex-wrap items-center gap-2 sm:gap-3 mt-8 sm:mt-10 pt-6 sm:pt-8 border-t-2 border-navy-900/10 text-xs sm:text-sm text-navy-700 font-medium w-full"
            >
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cream-200/80 border border-navy-900/20">
                <CheckCircle2 className="w-3.5 h-3.5 text-purple-electric shrink-0" />
                <span className="truncate">Modern React & TS</span>
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cream-200/80 border border-navy-900/20">
                <CheckCircle2 className="w-3.5 h-3.5 text-coral shrink-0" />
                <span className="truncate">Responsive & a11y</span>
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cream-200/80 border border-navy-900/20">
                <CheckCircle2 className="w-3.5 h-3.5 text-navy-900 shrink-0" />
                <span className="truncate">Fluid Micro-Interactions</span>
              </div>
            </motion.div>

          </div>

          {/* Right Column: Original Creative Visual Composition Card */}
          <div className="lg:col-span-5 relative flex justify-center items-center w-full mt-4 lg:mt-0">
            
            {/* Background geometric decorative shapes */}
            <div className="hidden sm:block absolute -top-5 -right-5 w-28 sm:w-32 h-28 sm:h-32 rounded-3xl bg-lime-accent border-2 border-navy-900 -rotate-6 shadow-brutal -z-0" />
            <div className="hidden sm:block absolute -bottom-6 -left-5 w-28 sm:w-36 h-28 sm:h-36 rounded-full bg-coral border-2 border-navy-900 rotate-12 shadow-brutal -z-0" />

            {/* Main Interactive Studio Composition Card with subtle float animation */}
            <motion.div
              initial={{ opacity: 0, scale: 0.93, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ ...smoothTransition, delay: 0.25 }}
              whileHover={{ y: -4 }}
              className="relative z-10 w-full max-w-md bg-white rounded-3xl border-3 border-navy-900 shadow-brutal-lg p-5 sm:p-7 overflow-hidden"
            >
              {/* Card Header Bar */}
              <div className="flex items-center justify-between pb-3.5 border-b-2 border-navy-900/10 mb-4 sm:mb-5">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-coral border border-navy-900"></span>
                  <span className="w-3 h-3 rounded-full bg-lime-accent border border-navy-900"></span>
                  <span className="w-3 h-3 rounded-full bg-purple-electric border border-navy-900"></span>
                </div>
                <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-cream-200 text-[10px] sm:text-[11px] font-mono font-bold text-navy-800">
                  <Terminal className="w-3 h-3 text-purple-electric" />
                  <span>portfolio.ts</span>
                </div>
              </div>

              {/* Developer Snapshot Mini-Card */}
              <div className="p-3.5 sm:p-4 rounded-2xl bg-purple-soft border-2 border-navy-900 shadow-brutal-sm mb-3.5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-purple-electric text-white flex items-center justify-center font-display font-bold text-base sm:text-lg border-2 border-navy-900 shadow-brutal-sm shrink-0">
                    <Code2 className="w-5 h-5 sm:w-6 sm:h-6 text-lime-accent" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-display font-bold text-navy-900 text-sm sm:text-base leading-tight truncate">
                      {personal.name}
                    </h3>
                    <p className="text-[11px] sm:text-xs text-purple-electric font-semibold mt-0.5 truncate">
                      {personal.role}
                    </p>
                  </div>
                </div>
                <div className="mt-3 pt-2.5 border-t border-purple-electric/20 flex items-center justify-between text-xs text-navy-700">
                  <span>Location</span>
                  <span className="font-semibold text-navy-900 truncate ml-2">{personal.location}</span>
                </div>
              </div>

              {/* Visual Tech Stack Floating Cards */}
              <div className="space-y-2">
                <div className="p-2.5 sm:p-3 rounded-xl bg-cream-100 border-2 border-navy-900 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-navy-900">
                    <Layers className="w-3.5 h-3.5 text-coral shrink-0" />
                    <span>Creative Frontend</span>
                  </div>
                  <span className="text-[10px] sm:text-[11px] font-mono bg-coral-soft text-coral px-2 py-0.5 rounded-md font-bold border border-coral/30">
                    TypeScript
                  </span>
                </div>

                <div className="p-2.5 sm:p-3 rounded-xl bg-lime-soft border-2 border-navy-900 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-navy-900">
                    <Sparkles className="w-3.5 h-3.5 text-navy-900 shrink-0" />
                    <span>Fluid Motion</span>
                  </div>
                  <span className="text-[10px] sm:text-[11px] font-mono bg-lime-accent text-navy-900 px-2 py-0.5 rounded-md font-bold border border-navy-900/30">
                    Motion / Framer
                  </span>
                </div>
              </div>

              {/* Editorial Quote Ribbon */}
              <div className="mt-4 p-2.5 sm:p-3 rounded-xl bg-cream-50 border-2 border-dashed border-navy-900/40 text-center">
                <p className="font-editorial-serif italic text-navy-800 text-xs sm:text-sm">
                  "{personal.personalMotto}"
                </p>
              </div>

              {/* Floating Sticker */}
              <motion.div
                animate={{ y: [0, -5, 0] }}
                transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute -top-2.5 -right-2.5 px-2.5 py-1 rounded-xl bg-lime-accent border-2 border-navy-900 shadow-brutal-sm font-display font-extrabold text-[10px] sm:text-xs text-navy-900 rotate-6"
              >
                ★ Ready to Build
              </motion.div>
            </motion.div>

          </div>

        </div>
      </div>

      {/* Scroll Down Indicator */}
      <div className="w-full flex justify-center pt-6 sm:pt-8">
        <motion.button
          whileHover={{ y: 2 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => scrollTo('about')}
          className="group flex flex-col items-center gap-1.5 text-navy-600 hover:text-purple-electric transition-colors focus:outline-none"
          aria-label="Scroll to About Section"
        >
          <span className="text-[10px] sm:text-xs font-mono font-bold uppercase tracking-wider">Scroll Down</span>
          <div className="w-5 h-8 sm:w-6 sm:h-10 rounded-full border-2 border-navy-900 flex items-start justify-center p-1 bg-white shadow-brutal-sm group-hover:border-purple-electric transition-colors">
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
              className="w-1.5 h-2.5 rounded-full bg-purple-electric"
            />
          </div>
        </motion.button>
      </div>
    </section>
  );
};
