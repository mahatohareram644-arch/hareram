import React from 'react';
import { ArrowUp, Sparkles } from 'lucide-react';
import { PersonalDetails } from '../types/portfolio';

interface FooterProps {
  personal: PersonalDetails;
}

export const Footer: React.FC<FooterProps> = ({ personal }) => {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-cream-100 text-navy-900 border-t-2 border-navy-900/10 py-12 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b-2 border-navy-900/10">
          
          {/* Logo & Identity */}
          <div className="flex items-center gap-3">
            <span className="w-9 h-9 rounded-xl bg-purple-electric text-lime-accent flex items-center justify-center border-2 border-navy-900 shadow-brutal-sm font-display font-bold">
              <Sparkles className="w-5 h-5 fill-current" />
            </span>
            <div>
              <p className="font-display font-extrabold text-base text-navy-900">
                {personal.name}
              </p>
              <p className="text-xs text-navy-600 font-mono">
                {personal.role}
              </p>
            </div>
          </div>

          {/* Quick Nav Links */}
          <div className="flex flex-wrap items-center justify-center gap-5 text-xs sm:text-sm font-semibold text-navy-700">
            <a href="#home" className="hover:text-purple-electric transition-colors">Home</a>
            <a href="#about" className="hover:text-purple-electric transition-colors">About</a>
            <a href="#skills" className="hover:text-purple-electric transition-colors">Skills</a>
            <a href="#projects" className="hover:text-purple-electric transition-colors">Projects</a>
            <a href="#journey" className="hover:text-purple-electric transition-colors">Journey</a>
            <a href="#contact" className="hover:text-purple-electric transition-colors">Contact</a>
          </div>

          {/* Return to Top Button */}
          <button
            onClick={scrollToTop}
            className="group inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-lime-accent text-navy-900 text-xs font-bold border-2 border-navy-900 shadow-brutal-sm hover:-translate-y-0.5 active:translate-y-0 transition-all"
            aria-label="Back to top of page"
          >
            <span>Back to Top</span>
            <ArrowUp className="w-4 h-4 group-hover:-translate-y-0.5 transition-transform" />
          </button>
        </div>

        {/* Bottom Bar: Copyright & Attribution */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-navy-600">
          <p>
            © {currentYear} {personal.name}. Built with React, TypeScript & Tailwind CSS.
          </p>
          <div className="flex items-center gap-1 font-medium">
            <span>Designed for creative storytelling & high performance</span>
          </div>
        </div>

      </div>
    </footer>
  );
};

