import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Milestone, 
  Briefcase, 
  GraduationCap, 
  Award, 
  Calendar, 
  MapPin, 
  CheckCircle2 
} from 'lucide-react';
import { JourneyItem, JourneyType } from '../types/portfolio';
import { smoothTransition } from '../utils/motion';

interface JourneyProps {
  journey: JourneyItem[];
}

export const Journey: React.FC<JourneyProps> = ({ journey }) => {
  const [selectedFilter, setSelectedFilter] = useState<JourneyType | 'all'>('all');

  const filteredJourney = selectedFilter === 'all'
    ? journey
    : journey.filter(item => item.type === selectedFilter);

  const getJourneyIcon = (type: JourneyType) => {
    switch (type) {
      case 'experience':
        return <Briefcase className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />;
      case 'education':
        return <GraduationCap className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />;
      case 'milestone':
      default:
        return <Award className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />;
    }
  };

  const getJourneyBadge = (type: JourneyType) => {
    switch (type) {
      case 'experience':
        return { label: 'Work Experience', bg: 'bg-purple-electric' };
      case 'education':
        return { label: 'Education', bg: 'bg-coral' };
      case 'milestone':
      default:
        return { label: 'Milestone', bg: 'bg-navy-900' };
    }
  };

  return (
    <section id="journey" className="py-16 sm:py-24 bg-paper-texture relative overflow-hidden border-t-2 border-navy-900/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={smoothTransition}
          className="flex flex-col md:flex-row md:items-end justify-between gap-4 sm:gap-6 mb-8 sm:mb-12"
        >
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white border-2 border-navy-900 shadow-brutal-sm text-xs font-mono font-bold uppercase tracking-wider text-purple-electric mb-3">
              <Milestone className="w-3.5 h-3.5" />
              <span>04 / Background & Timeline</span>
            </div>
            <h2 className="font-display font-extrabold text-2xl sm:text-4xl lg:text-5xl text-navy-900 tracking-tight leading-tight">
              Experience &{' '}
              <span className="font-editorial-serif font-normal italic text-coral">Learning</span>{' '}
              Journey.
            </h2>
          </div>
          <p className="text-xs sm:text-sm lg:text-base text-navy-600 max-w-md">
            Milestones, academic foundations, and practical engineering experiences that shaped my approach.
          </p>
        </motion.div>

        {/* Filter Buttons - Horizontal swipe on mobile */}
        <div className="overflow-x-auto no-scrollbar -mx-4 px-4 sm:mx-0 sm:px-0 mb-8 sm:mb-12 pb-2">
          <div className="flex items-center gap-2 min-w-max">
            {(['all', 'experience', 'education', 'milestone'] as const).map((filter) => {
              const isSelected = selectedFilter === filter;
              const labels: Record<string, string> = {
                all: 'Complete Timeline',
                experience: 'Work Experience',
                education: 'Education',
                milestone: 'Milestones'
              };

              return (
                <motion.button
                  key={filter}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedFilter(filter)}
                  className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold border-2 transition-all ${
                    isSelected
                      ? 'bg-purple-electric text-white border-navy-900 shadow-brutal-sm -translate-y-0.5'
                      : 'bg-white text-navy-800 border-navy-900/20 hover:border-navy-900 hover:bg-cream-200'
                  }`}
                >
                  {labels[filter]}
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Timeline Layout - Perfectly padded for narrow mobile displays */}
        <div className="relative border-l-3 border-navy-900 ml-3 sm:ml-8 pl-5 sm:pl-10 space-y-8 sm:space-y-10">
          <AnimatePresence mode="popLayout">
            {filteredJourney.map((item, index) => {
              const badge = getJourneyBadge(item.type);

              return (
                <motion.div
                  layout
                  initial={{ opacity: 0, x: -16 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -16 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 28, delay: index * 0.06 }}
                  key={item.id}
                  className="relative group"
                >
                  {/* Timeline node circle */}
                  <div className={`absolute -left-[32px] sm:-left-[51px] top-4 w-6 h-6 sm:w-8 sm:h-8 rounded-full ${badge.bg} border-2 border-navy-900 shadow-brutal-sm flex items-center justify-center shrink-0`}>
                    {getJourneyIcon(item.type)}
                  </div>

                  {/* Card Content */}
                  <div className="p-4 sm:p-7 rounded-3xl bg-white border-3 border-navy-900 shadow-brutal hover:shadow-brutal-lg transition-all">
                    
                    {/* Period and Category Pill */}
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
                      <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-cream-200 text-[11px] sm:text-xs font-mono font-bold text-navy-900 border border-navy-900/20">
                          <Calendar className="w-3 h-3 text-purple-electric" />
                          {item.period}
                        </span>
                        <span className={`px-2 py-0.5 rounded-md text-[10px] sm:text-[11px] font-mono font-bold text-white ${badge.bg}`}>
                          {badge.label}
                        </span>
                      </div>

                      {item.isPlaceholder && (
                        <span className="text-[9px] sm:text-[10px] font-mono font-semibold bg-lime-soft text-navy-800 px-2 py-0.5 rounded border border-navy-900/20">
                          Customizable
                        </span>
                      )}
                    </div>

                    {/* Role / Degree Title */}
                    <h3 className="font-display font-extrabold text-lg sm:text-2xl text-navy-900">
                      {item.title}
                    </h3>

                    {/* Organization and Location */}
                    <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs sm:text-sm text-navy-600 font-medium mt-1 mb-3.5">
                      <span className="font-bold text-navy-900">{item.organization}</span>
                      {item.location && (
                        <span className="flex items-center gap-1 text-navy-500">
                          <MapPin className="w-3 h-3 text-coral" />
                          {item.location}
                        </span>
                      )}
                    </div>

                    {/* Description */}
                    <p className="text-xs sm:text-sm lg:text-base text-navy-700 leading-relaxed mb-3.5">
                      {item.description}
                    </p>

                    {/* Highlights bullet points */}
                    {item.highlights && item.highlights.length > 0 && (
                      <ul className="space-y-1.5 mb-4 pt-3 border-t border-navy-900/10">
                        {item.highlights.map((highlight, hIdx) => (
                          <li key={hIdx} className="flex items-start gap-2 text-xs sm:text-sm text-navy-800">
                            <CheckCircle2 className="w-3.5 h-3.5 text-purple-electric shrink-0 mt-0.5" />
                            <span>{highlight}</span>
                          </li>
                        ))}
                      </ul>
                    )}

                    {/* Skills/Tags */}
                    {item.tags && item.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {item.tags.map((tag) => (
                          <span
                            key={tag}
                            className="px-2 py-0.5 rounded-lg bg-purple-soft text-navy-800 text-[10px] sm:text-xs font-mono font-bold border border-purple-electric/20"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}

                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>

      </div>
    </section>
  );
};
