import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, ArrowUpRight, Sparkles, Github, Linkedin, Mail } from 'lucide-react';
import { PersonalDetails } from '../types/portfolio';
import { drawerVariants, itemVariants } from '../utils/motion';

interface NavbarProps {
  personal: PersonalDetails;
  activeSection: string;
}

const navItems = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'skills', label: 'Skills' },
  { id: 'projects', label: 'Projects' },
  { id: 'journey', label: 'Journey' },
  { id: 'contact', label: 'Contact' },
];

export const Navbar: React.FC<NavbarProps> = ({ personal, activeSection }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen]);

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const isMobile = window.innerWidth < 768;
      const navHeight = isMobile ? 68 : 84;
      const elementPosition = element.getBoundingClientRect().top + window.scrollY;
      window.scrollTo({
        top: elementPosition - navHeight,
        behavior: 'smooth',
      });
    }
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'py-2.5 sm:py-3 bg-cream-100/95 backdrop-blur-md border-b-2 border-navy-900/10 shadow-sm'
            : 'py-4 sm:py-5 bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex items-center justify-between" aria-label="Main Navigation">
            {/* Logo / Brand Name */}
            <a
              href="#home"
              onClick={(e) => {
                e.preventDefault();
                scrollTo('home');
              }}
              className="group flex items-center gap-2.5 text-navy-900 font-display font-bold text-base sm:text-xl tracking-tight focus:outline-none"
            >
              <span className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-purple-electric text-lime-accent flex items-center justify-center border-2 border-navy-900 shadow-brutal-sm group-hover:rotate-6 transition-transform">
                <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 fill-current" />
              </span>
              <span className="flex items-center gap-1.5">
                <span className="truncate max-w-[180px] sm:max-w-none">{personal.name}</span>
                <span className="w-2 h-2 rounded-full bg-coral inline-block shrink-0"></span>
              </span>
            </a>

            {/* Desktop Navigation Links */}
            <div className="hidden md:flex items-center gap-1 bg-white/90 backdrop-blur-sm p-1.5 rounded-full border-2 border-navy-900 shadow-brutal-sm">
              {navItems.map((item) => {
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => scrollTo(item.id)}
                    className={`relative px-4 py-1.5 text-sm font-bold rounded-full transition-colors duration-200 ${
                      isActive ? 'text-white' : 'text-navy-900 hover:text-purple-electric'
                    }`}
                  >
                    {isActive && (
                      <motion.div
                        layoutId="activeNavIndicator"
                        className="absolute inset-0 bg-purple-electric rounded-full -z-0"
                        transition={{ type: 'spring', stiffness: 450, damping: 35 }}
                      />
                    )}
                    <span className="relative z-10">{item.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Right Action / CTA */}
            <div className="hidden md:flex items-center gap-3">
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => scrollTo('contact')}
                className="group flex items-center gap-2 px-4 py-2 bg-lime-accent hover:bg-lime-hover text-navy-900 text-sm font-bold rounded-xl border-2 border-navy-900 shadow-brutal-sm hover:shadow-brutal transition-all"
              >
                <span>Let's Talk</span>
                <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </motion.button>
            </div>

            {/* Mobile Menu Button - min 44x44px touch target */}
            <div className="flex md:hidden items-center gap-2">
              <motion.button
                whileTap={{ scale: 0.92 }}
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl bg-white border-2 border-navy-900 shadow-brutal-sm text-navy-900 hover:bg-cream-200 transition-colors"
                aria-label={mobileMenuOpen ? 'Close Menu' : 'Open Menu'}
                aria-expanded={mobileMenuOpen}
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </motion.button>
            </div>
          </nav>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileMenuOpen(false)}
              className="fixed inset-0 bg-navy-900/60 z-40 md:hidden backdrop-blur-sm"
            />

            {/* Slide-over panel */}
            <motion.div
              variants={drawerVariants}
              initial="closed"
              animate="open"
              exit="closed"
              className="fixed top-0 right-0 bottom-0 w-[86%] max-w-sm bg-cream-100 z-50 md:hidden border-l-3 border-navy-900 p-6 flex flex-col justify-between shadow-2xl overflow-y-auto"
            >
              <div>
                {/* Drawer Header */}
                <div className="flex items-center justify-between pb-5 border-b-2 border-navy-900/10">
                  <div className="flex items-center gap-2.5">
                    <span className="w-8 h-8 rounded-lg bg-purple-electric text-lime-accent flex items-center justify-center border-2 border-navy-900 font-display font-extrabold text-sm">
                      {personal.name ? personal.name.charAt(0) : 'H'}
                    </span>
                    <span className="font-display font-bold text-navy-900 text-sm truncate max-w-[170px]">
                      {personal.name}
                    </span>
                  </div>
                  <motion.button
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setMobileMenuOpen(false)}
                    className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl bg-white border-2 border-navy-900 shadow-brutal-sm text-navy-900"
                    aria-label="Close menu"
                  >
                    <X className="w-4 h-4" />
                  </motion.button>
                </div>

                {/* Staggered Navigation Items */}
                <div className="flex flex-col gap-2 mt-5">
                  {navItems.map((item) => {
                    const isActive = activeSection === item.id;
                    return (
                      <motion.button
                        key={item.id}
                        variants={itemVariants}
                        whileTap={{ scale: 0.97 }}
                        onClick={() => scrollTo(item.id)}
                        className={`min-h-[48px] flex items-center justify-between px-4 py-2.5 rounded-xl font-display font-bold text-base text-left border-2 transition-all ${
                          isActive
                            ? 'bg-purple-electric text-white border-navy-900 shadow-brutal-sm translate-x-1'
                            : 'bg-white text-navy-900 border-navy-900/20 hover:border-navy-900 hover:bg-purple-soft'
                        }`}
                      >
                        <span>{item.label}</span>
                        {isActive && (
                          <span className="w-2.5 h-2.5 rounded-full bg-lime-accent border border-navy-900" />
                        )}
                      </motion.button>
                    );
                  })}
                </div>
              </div>

              {/* Bottom Quick Actions & Socials in Mobile Drawer */}
              <div className="pt-5 border-t-2 border-navy-900/10 flex flex-col gap-4">
                <motion.button
                  whileTap={{ scale: 0.96 }}
                  onClick={() => scrollTo('contact')}
                  className="w-full min-h-[48px] flex items-center justify-center gap-2 py-3 bg-coral hover:bg-coral-hover text-white font-bold rounded-xl border-2 border-navy-900 shadow-brutal-sm"
                >
                  <span>Let's Connect</span>
                  <ArrowUpRight className="w-4 h-4" />
                </motion.button>

                {/* Quick Social Icons in Drawer */}
                <div className="flex items-center justify-center gap-3 pt-1">
                  {personal.github && (
                    <a
                      href={personal.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-xl bg-white border-2 border-navy-900 shadow-brutal-sm flex items-center justify-center text-navy-900 hover:bg-lime-accent transition-colors"
                      aria-label="GitHub"
                    >
                      <Github className="w-4 h-4" />
                    </a>
                  )}
                  {personal.linkedin && (
                    <a
                      href={personal.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-xl bg-white border-2 border-navy-900 shadow-brutal-sm flex items-center justify-center text-navy-900 hover:bg-lime-accent transition-colors"
                      aria-label="LinkedIn"
                    >
                      <Linkedin className="w-4 h-4 text-[#0077B5]" />
                    </a>
                  )}
                  {personal.email && (
                    <a
                      href={`mailto:${personal.email}`}
                      className="w-10 h-10 rounded-xl bg-white border-2 border-navy-900 shadow-brutal-sm flex items-center justify-center text-navy-900 hover:bg-lime-accent transition-colors"
                      aria-label="Email"
                    >
                      <Mail className="w-4 h-4 text-purple-electric" />
                    </a>
                  )}
                </div>

                <p className="text-[11px] text-navy-600 text-center font-medium">
                  {personal.availability.label}
                </p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};
