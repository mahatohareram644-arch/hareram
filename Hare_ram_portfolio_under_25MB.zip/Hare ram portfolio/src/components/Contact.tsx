import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Send, 
  Copy, 
  Check, 
  Github, 
  Linkedin, 
  Twitter, 
  ArrowUpRight, 
  MessageSquare,
  Sparkles,
  Info
} from 'lucide-react';
import { PersonalDetails } from '../types/portfolio';
import { smoothTransition } from '../utils/motion';

interface ContactProps {
  personal: PersonalDetails;
}

export const Contact: React.FC<ContactProps> = ({ personal }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const copyEmail = () => {
    navigator.clipboard.writeText(personal.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.name.trim()) errs.name = 'Please provide your name.';
    if (!formData.email.trim()) {
      errs.email = 'Please provide your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errs.email = 'Please enter a valid email address.';
    }
    if (!formData.subject.trim()) errs.subject = 'Please add a subject.';
    if (!formData.message.trim()) {
      errs.message = 'Please write a brief message.';
    } else if (formData.message.trim().length < 10) {
      errs.message = 'Message should be at least 10 characters.';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setStatus('submitting');
    setStatusMessage('');

    const { contactConfig } = personal;

    // Direct Formspree Mode
    if (contactConfig.mode === 'formspree' && contactConfig.formspreeId) {
      try {
        const response = await fetch(`https://formspree.io/f/${contactConfig.formspreeId}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify(formData),
        });

        if (response.ok) {
          setStatus('success');
          setStatusMessage('Thank you! Your message was sent successfully via Formspree.');
          setFormData({ name: '', email: '', subject: '', message: '' });
        } else {
          setStatus('error');
          setStatusMessage('Failed to send message via Formspree. Please try using direct email.');
        }
      } catch {
        setStatus('error');
        setStatusMessage('Network error occurred. Please reach out via direct email.');
      }
      return;
    }

    // Direct Web3Forms Mode
    if (contactConfig.mode === 'web3forms' && contactConfig.web3formsAccessKey) {
      try {
        const response = await fetch('https://api.web3forms.com/submit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify({
            access_key: contactConfig.web3formsAccessKey,
            ...formData,
          }),
        });

        const result = await response.json();
        if (result.success) {
          setStatus('success');
          setStatusMessage('Thank you! Your message was delivered successfully.');
          setFormData({ name: '', email: '', subject: '', message: '' });
        } else {
          setStatus('error');
          setStatusMessage(result.message || 'Submission error. Please contact directly via email.');
        }
      } catch {
        setStatus('error');
        setStatusMessage('Network error occurred. Please contact directly via email.');
      }
      return;
    }

    // Default 'mailto' zero-config mode:
    const mailtoSubject = encodeURIComponent(`[Portfolio Inquiry] ${formData.subject}`);
    const mailtoBody = encodeURIComponent(
      `Hello ${personal.name},\n\n` +
      `${formData.message}\n\n` +
      `From: ${formData.name} (${formData.email})`
    );
    const mailtoUrl = `mailto:${personal.email}?subject=${mailtoSubject}&body=${mailtoBody}`;

    window.location.href = mailtoUrl;

    setStatus('success');
    setStatusMessage(`Opening your email client to dispatch this message directly to ${personal.email}. If it doesn't open automatically, use the copy button.`);
  };

  return (
    <section id="contact" className="py-16 sm:py-24 bg-purple-electric text-white relative overflow-hidden border-t-3 border-navy-900">
      
      {/* Decorative background shapes */}
      <div className="absolute top-0 right-0 w-64 sm:w-80 h-64 sm:h-80 rounded-full bg-coral/30 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-72 sm:w-96 h-72 sm:h-96 rounded-full bg-lime-accent/20 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 sm:gap-14 lg:gap-16 items-start">
          
          {/* Left Column: Bold Headline & Direct Social Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={smoothTransition}
            className="lg:col-span-5 flex flex-col items-start w-full"
          >
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-lime-accent text-navy-900 border-2 border-navy-900 shadow-brutal-sm text-xs font-mono font-extrabold uppercase tracking-wider mb-5 sm:mb-6">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Get In Touch</span>
            </div>

            <h2 className="font-display font-extrabold text-3xl sm:text-5xl lg:text-6xl tracking-tight leading-[1.1] mb-5 sm:mb-6">
              Have an Idea?{' '}
              <span className="font-editorial-serif font-normal italic text-lime-accent">
                Let's Make
              </span>{' '}
              It Happen.
            </h2>

            <p className="text-purple-100 text-sm sm:text-base lg:text-lg leading-relaxed mb-6 sm:mb-8">
              Whether you are looking to build a new product, refactor a complex frontend, or explore a collaborative venture, my inbox is always open.
            </p>

            {/* Direct Email Card with One-Click Copy */}
            <div className="w-full p-4 sm:p-5 rounded-2xl bg-white text-navy-900 border-3 border-navy-900 shadow-brutal mb-6 sm:mb-8">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] sm:text-xs font-mono font-bold uppercase tracking-wider text-navy-500">
                  Direct Email
                </span>
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.94 }}
                  onClick={copyEmail}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-lime-accent hover:bg-lime-hover text-navy-900 text-xs font-bold border border-navy-900 shadow-brutal-sm transition-all"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-green-700" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Email</span>
                    </>
                  )}
                </motion.button>
              </div>
              <a
                href={`mailto:${personal.email}`}
                className="font-display font-bold text-sm sm:text-base md:text-lg text-purple-electric hover:underline break-all"
              >
                {personal.email}
              </a>
            </div>

            {/* Social Network Links */}
            <div className="w-full">
              <p className="text-[11px] sm:text-xs font-mono font-bold uppercase tracking-wider text-purple-200 mb-3">
                Connect Online
              </p>
              <div className="flex flex-wrap gap-2.5 sm:gap-3">
                {personal.github && (
                  <motion.a
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.96 }}
                    href={personal.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="min-h-[44px] inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white text-navy-900 border-2 border-navy-900 shadow-brutal-sm hover:shadow-brutal transition-all text-xs sm:text-sm font-bold"
                  >
                    <Github className="w-4 h-4" />
                    <span>GitHub</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-navy-500" />
                  </motion.a>
                )}

                {personal.linkedin && (
                  <motion.a
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.96 }}
                    href={personal.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="min-h-[44px] inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white text-navy-900 border-2 border-navy-900 shadow-brutal-sm hover:shadow-brutal transition-all text-xs sm:text-sm font-bold"
                  >
                    <Linkedin className="w-4 h-4 text-[#0077B5]" />
                    <span>LinkedIn</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-navy-500" />
                  </motion.a>
                )}

                {personal.twitter && (
                  <motion.a
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.96 }}
                    href={personal.twitter}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="min-h-[44px] inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white text-navy-900 border-2 border-navy-900 shadow-brutal-sm hover:shadow-brutal transition-all text-xs sm:text-sm font-bold"
                  >
                    <Twitter className="w-4 h-4" />
                    <span>Twitter</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-navy-500" />
                  </motion.a>
                )}
              </div>
            </div>

          </motion.div>

          {/* Right Column: Functional Contact Form */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={smoothTransition}
            className="lg:col-span-7 w-full"
          >
            <div className="bg-white text-navy-900 rounded-3xl border-3 border-navy-900 shadow-brutal-lg p-5 sm:p-8 lg:p-9">
              
              <div className="flex items-center gap-2 mb-5 pb-3.5 border-b-2 border-navy-900/10">
                <MessageSquare className="w-5 h-5 text-purple-electric shrink-0" />
                <h3 className="font-display font-extrabold text-lg sm:text-2xl text-navy-900">
                  Send a Direct Message
                </h3>
              </div>

              <form onSubmit={handleSubmit} noValidate className="space-y-4">
                
                {/* Name & Email Row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 sm:gap-4">
                  <div>
                    <label className="block text-[11px] sm:text-xs font-mono font-bold uppercase tracking-wider text-navy-700 mb-1">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Jane Doe"
                      className={`w-full px-3.5 py-2.5 rounded-xl border-2 text-base text-navy-900 placeholder-navy-400 bg-cream-50 focus:bg-white transition-all ${
                        errors.name ? 'border-coral ring-1 ring-coral' : 'border-navy-900'
                      }`}
                    />
                    {errors.name && (
                      <p className="text-xs text-coral font-bold mt-1">{errors.name}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-[11px] sm:text-xs font-mono font-bold uppercase tracking-wider text-navy-700 mb-1">
                      Your Email *
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="jane@example.com"
                      className={`w-full px-3.5 py-2.5 rounded-xl border-2 text-base text-navy-900 placeholder-navy-400 bg-cream-50 focus:bg-white transition-all ${
                        errors.email ? 'border-coral ring-1 ring-coral' : 'border-navy-900'
                      }`}
                    />
                    {errors.email && (
                      <p className="text-xs text-coral font-bold mt-1">{errors.email}</p>
                    )}
                  </div>
                </div>

                {/* Subject */}
                <div>
                  <label className="block text-[11px] sm:text-xs font-mono font-bold uppercase tracking-wider text-navy-700 mb-1">
                    Subject *
                  </label>
                  <input
                    type="text"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    placeholder="Project Inquiry / Job Opportunity / Hello"
                    className={`w-full px-3.5 py-2.5 rounded-xl border-2 text-base text-navy-900 placeholder-navy-400 bg-cream-50 focus:bg-white transition-all ${
                      errors.subject ? 'border-coral ring-1 ring-coral' : 'border-navy-900'
                    }`}
                  />
                  {errors.subject && (
                    <p className="text-xs text-coral font-bold mt-1">{errors.subject}</p>
                  )}
                </div>

                {/* Message */}
                <div>
                  <label className="block text-[11px] sm:text-xs font-mono font-bold uppercase tracking-wider text-navy-700 mb-1">
                    Message *
                  </label>
                  <textarea
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Tell me a bit about what you're looking to achieve..."
                    className={`w-full px-3.5 py-2.5 rounded-xl border-2 text-base text-navy-900 placeholder-navy-400 bg-cream-50 focus:bg-white transition-all resize-y ${
                      errors.message ? 'border-coral ring-1 ring-coral' : 'border-navy-900'
                    }`}
                  />
                  {errors.message && (
                    <p className="text-xs text-coral font-bold mt-1">{errors.message}</p>
                  )}
                </div>

                {/* Status Notice */}
                {statusMessage && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`p-3.5 rounded-xl border-2 text-xs font-medium leading-relaxed ${
                      status === 'success'
                        ? 'bg-lime-soft border-navy-900 text-navy-900'
                        : 'bg-coral-soft border-coral text-navy-900'
                    }`}
                  >
                    {statusMessage}
                  </motion.div>
                )}

                {/* Submit Button */}
                <motion.button
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  disabled={status === 'submitting'}
                  className="w-full min-h-[48px] flex items-center justify-center gap-2 py-3.5 px-6 rounded-2xl bg-coral hover:bg-coral-hover text-white text-base font-bold border-2 border-navy-900 shadow-brutal hover:shadow-brutal-lg transition-all disabled:opacity-60"
                >
                  <Send className="w-4 h-4" />
                  <span>
                    {status === 'submitting' ? 'Sending Message...' : 'Send Message'}
                  </span>
                </motion.button>

                {/* Notice & Transparent Backend Explanation */}
                <div className="pt-2 flex items-start gap-2 text-[11px] text-navy-600">
                  <Info className="w-3.5 h-3.5 text-purple-electric shrink-0 mt-0.5" />
                  <span>
                    {personal.contactConfig.noticeText ||
                      "Direct submission via client mail client or configured endpoint in portfolio.ts."}
                  </span>
                </div>

              </form>

            </div>
          </motion.div>

        </div>

      </div>
    </section>
  );
};
