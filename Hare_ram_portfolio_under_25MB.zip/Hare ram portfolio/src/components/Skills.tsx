import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Wrench, 
  Code, 
  Layout, 
  Server, 
  PenTool, 
  TerminalSquare, 
  Sparkles,
  Filter
} from 'lucide-react';
import { Skill, SkillCategory } from '../types/portfolio';
import { smoothTransition } from '../utils/motion';

interface SkillsProps {
  skills: Skill[];
}

interface CategoryConfig {
  id: SkillCategory | 'all';
  label: string;
  icon: React.FC<{ className?: string }>;
}

const categories: CategoryConfig[] = [
  { id: 'all', label: 'All Skills', icon: Sparkles },
  { id: 'languages', label: 'Languages', icon: Code },
  { id: 'frontend', label: 'Frontend', icon: Layout },
  { id: 'backend', label: 'Backend', icon: Server },
  { id: 'tools', label: 'Developer Tools', icon: TerminalSquare },
  { id: 'design', label: 'Design & UI', icon: PenTool },
];

export const Skills: React.FC<SkillsProps> = ({ skills }) => {
  const [selectedCategory, setSelectedCategory] = useState<SkillCategory | 'all'>('all');

  const filteredSkills = selectedCategory === 'all'
    ? skills
    : skills.filter(skill => skill.category === selectedCategory);

  const getCategoryBadge = (cat: SkillCategory) => {
    switch (cat) {
      case 'languages':
        return { label: 'Language', bg: 'bg-lime-accent text-navy-900 border-navy-900' };
      case 'frontend':
        return { label: 'Frontend', bg: 'bg-purple-electric text-white border-navy-900' };
      case 'backend':
        return { label: 'Backend', bg: 'bg-coral text-white border-navy-900' };
      case 'tools':
        return { label: 'Tooling', bg: 'bg-navy-900 text-white border-navy-900' };
      case 'design':
        return { label: 'Design', bg: 'bg-lime-accent text-navy-900 border-navy-900' };
      default:
        return { label: 'Skill', bg: 'bg-cream-200 text-navy-900 border-navy-900' };
    }
  };

  return (
    <section id="skills" className="py-16 sm:py-24 bg-cream-100 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={smoothTransition}
          className="flex flex-col md:flex-row md:items-end justify-between gap-4 sm:gap-6 mb-8 sm:mb-12"
        >
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white border-2 border-navy-900 shadow-brutal-sm text-xs font-mono font-bold uppercase tracking-wider text-purple-electric mb-3">
              <Wrench className="w-3.5 h-3.5" />
              <span>02 / Capabilities</span>
            </div>
            <h2 className="font-display font-extrabold text-2xl sm:text-4xl lg:text-5xl text-navy-900 tracking-tight leading-tight">
              Skills &{' '}
              <span className="font-editorial-serif font-normal italic text-coral">Engineering</span>{' '}
              Toolkit.
            </h2>
          </div>
          <p className="text-xs sm:text-sm lg:text-base text-navy-600 max-w-md">
            Verified technologies and toolchains utilized to build modern, performant web applications with confidence.
          </p>
        </motion.div>

        {/* Category Filter Tabs - Smooth horizontal swipeable on mobile */}
        <div className="overflow-x-auto no-scrollbar -mx-4 px-4 sm:mx-0 sm:px-0 mb-8 sm:mb-10 pb-2">
          <div className="flex items-center gap-2 min-w-max">
            {categories.map((cat) => {
              const Icon = cat.icon;
              const isSelected = selectedCategory === cat.id;
              const count = cat.id === 'all' ? skills.length : skills.filter(s => s.category === cat.id).length;

              return (
                <motion.button
                  key={cat.id}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`inline-flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold border-2 transition-all ${
                    isSelected
                      ? 'bg-purple-electric text-white border-navy-900 shadow-brutal-sm -translate-y-0.5'
                      : 'bg-white text-navy-800 border-navy-900/20 hover:border-navy-900 hover:bg-cream-200'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-lime-accent' : 'text-purple-electric'}`} />
                  <span>{cat.label}</span>
                  <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-md ${isSelected ? 'bg-white/20 text-white' : 'bg-cream-300 text-navy-700'}`}>
                    {count}
                  </span>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Skills Cards Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4"
        >
          <AnimatePresence mode="popLayout">
            {filteredSkills.map((skill) => {
              const badge = getCategoryBadge(skill.category);
              return (
                <motion.div
                  layout
                  initial={{ opacity: 0, scale: 0.92 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.92 }}
                  transition={{ type: 'spring', stiffness: 350, damping: 28 }}
                  whileHover={{ y: -4 }}
                  whileTap={{ scale: 0.98 }}
                  key={skill.name}
                  className="group relative p-3.5 sm:p-4 rounded-2xl bg-white border-2 border-navy-900 shadow-brutal-sm hover:shadow-brutal transition-all flex flex-col justify-between"
                >
                  <div className="flex items-start justify-between gap-2 mb-2.5">
                    <span className={`text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border ${badge.bg}`}>
                      {badge.label}
                    </span>
                    {skill.level && (
                      <span className="text-[10px] sm:text-[11px] font-semibold text-navy-500">
                        {skill.level}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-lime-accent border border-navy-900 group-hover:scale-125 transition-transform shrink-0" />
                    <h3 className="font-display font-bold text-sm sm:text-base text-navy-900 group-hover:text-purple-electric transition-colors truncate">
                      {skill.name}
                    </h3>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </motion.div>

        {/* Informative Note for Customization */}
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-10 sm:mt-12 p-3.5 sm:p-4 rounded-2xl bg-cream-200/60 border-2 border-dashed border-navy-900/30 flex items-center justify-between flex-wrap gap-2 text-xs text-navy-700"
        >
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-purple-electric shrink-0" />
            <span className="text-[11px] sm:text-xs">
              All skills managed centrally in <code className="font-mono bg-white px-1.5 py-0.5 rounded border border-navy-900/20 font-bold">src/data/portfolio.ts</code>.
            </span>
          </div>
          <span className="font-mono text-[10px] sm:text-[11px] text-navy-500">True capabilities only.</span>
        </motion.div>

      </div>
    </section>
  );
};
