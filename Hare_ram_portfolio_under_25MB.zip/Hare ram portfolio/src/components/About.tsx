import React from 'react';
import { motion } from 'framer-motion';
import { User, Quote, MapPin, Sparkles, Heart, Terminal, Compass } from 'lucide-react';
import { PersonalDetails } from '../types/portfolio';
import { smoothTransition } from '../utils/motion';

interface AboutProps {
  personal: PersonalDetails;
}

export const About: React.FC<AboutProps> = ({ personal }) => {
  return (
    <section id="about" className="py-16 sm:py-24 bg-purple-soft relative overflow-hidden border-y-2 border-navy-900/10">
      {/* Background soft ambient shapes */}
      <div className="absolute top-0 right-0 w-72 sm:w-96 h-72 sm:h-96 bg-purple-light/50 rounded-full blur-3xl pointer-events-none -z-0" />
      <div className="absolute bottom-0 left-0 w-60 sm:w-80 h-60 sm:h-80 bg-lime-soft/60 rounded-full blur-3xl pointer-events-none -z-0" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={smoothTransition}
          className="flex flex-col items-start mb-10 sm:mb-16"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white border-2 border-navy-900 shadow-brutal-sm text-xs font-mono font-bold uppercase tracking-wider text-purple-electric mb-3">
            <User className="w-3.5 h-3.5" />
            <span>01 / Biography</span>
          </div>
          <h2 className="font-display font-extrabold text-2xl sm:text-4xl lg:text-5xl text-navy-900 tracking-tight leading-tight">
            Curious Mind,{' '}
            <span className="font-editorial-serif font-normal italic text-purple-electric">Creative</span>{' '}
            Developer.
          </h2>
        </motion.div>

        {/* Asymmetric Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-12 items-start">
          
          {/* Left Column: Creative Profile Avatar & Fast Fact Cards */}
          <div className="lg:col-span-5 flex flex-col gap-6 w-full">
            
            {/* Profile Photo Placeholder with Graphic Frame */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={smoothTransition}
              className="relative w-full"
            >
              <div className="relative bg-white rounded-3xl border-3 border-navy-900 shadow-brutal-lg p-4 sm:p-6 overflow-hidden">
                
                {/* Visual Avatar Placeholder / Creative Portrait */}
                <div className="aspect-[4/3] rounded-2xl bg-cream-200 border-2 border-navy-900 overflow-hidden relative flex flex-col items-center justify-center p-4 sm:p-6 text-center group">
                  {personal.avatarUrl ? (
                    <img
                      src={personal.avatarUrl}
                      alt={personal.name}
                      className="w-full h-full object-cover rounded-xl"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center gap-2.5">
                      <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-purple-electric text-lime-accent flex items-center justify-center border-2 border-navy-900 shadow-brutal-sm group-hover:scale-105 transition-transform">
                        <Sparkles className="w-8 h-8 sm:w-10 sm:h-10 fill-current" />
                      </div>
                      <div>
                        <p className="font-display font-bold text-navy-900 text-sm sm:text-base">
                          {personal.name}
                        </p>
                        <p className="text-[11px] sm:text-xs text-navy-600 font-mono mt-0.5 truncate max-w-[200px]">
                          {personal.role}
                        </p>
                      </div>
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white text-[10px] sm:text-[11px] font-bold text-navy-700 border border-navy-900/30">
                        <MapPin className="w-3 h-3 text-coral" />
                        {personal.location}
                      </span>
                    </div>
                  )}

                  {/* Corner Badge */}
                  <div className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-lg bg-lime-accent text-navy-900 border-2 border-navy-900 shadow-brutal-sm text-[10px] sm:text-[11px] font-mono font-bold">
                    Portfolio
                  </div>
                </div>

                {/* Subtitle status bar */}
                <div className="mt-3.5 pt-3.5 border-t-2 border-navy-900/10 flex items-center justify-between text-xs text-navy-600">
                  <span className="flex items-center gap-1.5 font-medium truncate">
                    <Compass className="w-3.5 h-3.5 text-purple-electric shrink-0" />
                    <span>Open to Collaborations</span>
                  </span>
                  <span className="font-mono font-bold text-navy-900 shrink-0 ml-2">
                    {personal.availability.status}
                  </span>
                </div>
              </div>
            </motion.div>

            {/* Quick Fact Cards Grid - 2 cols on mobile, comfortable touch padding */}
            <div className="grid grid-cols-2 gap-3 sm:gap-4 w-full">
              {personal.quickFacts.map((fact, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ ...smoothTransition, delay: index * 0.08 }}
                  whileHover={{ y: -3 }}
                  className={`p-3 sm:p-4 rounded-2xl border-2 border-navy-900 shadow-brutal-sm transition-transform ${
                    fact.highlight ? 'bg-lime-accent text-navy-900' : 'bg-white text-navy-900'
                  }`}
                >
                  <p className="text-[10px] sm:text-xs font-mono font-bold text-navy-700 uppercase tracking-wider mb-1 truncate">
                    {fact.label}
                  </p>
                  <p className="font-display font-extrabold text-xs sm:text-sm sm:text-base leading-snug">
                    {fact.value}
                  </p>
                </motion.div>
              ))}
            </div>

          </div>

          {/* Right Column: Bio Paragraphs, Editorial Motto & Interests */}
          <div className="lg:col-span-7 flex flex-col gap-6 sm:gap-8 w-full">
            
            {/* Bio Body */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ ...smoothTransition, delay: 0.1 }}
              className="bg-white rounded-3xl border-3 border-navy-900 shadow-brutal-lg p-5 sm:p-8 lg:p-9"
            >
              <div className="flex items-center gap-2 text-xs font-mono font-bold text-navy-500 uppercase tracking-wider mb-4">
                <Terminal className="w-4 h-4 text-purple-electric" />
                <span>The Story & Perspective</span>
              </div>

              <div className="space-y-4 text-sm sm:text-base lg:text-lg text-navy-800 leading-relaxed">
                {personal.aboutParagraphs.map((paragraph, idx) => (
                  <p key={idx} className={idx === 0 ? 'text-base sm:text-lg lg:text-xl font-medium text-navy-900' : ''}>
                    {paragraph}
                  </p>
                ))}
              </div>

              {/* Personal Motto Card */}
              <div className="mt-6 sm:mt-8 p-4 sm:p-5 rounded-2xl bg-cream-100 border-2 border-navy-900 shadow-brutal-sm relative">
                <Quote className="w-6 h-6 sm:w-8 sm:h-8 text-coral absolute -top-3 left-2 sm:-top-4 sm:-left-2 fill-current rotate-180" />
                <p className="font-editorial-serif text-base sm:text-xl text-navy-900 italic pl-4 sm:pl-3 leading-snug">
                  "{personal.personalMotto}"
                </p>
                <p className="text-xs font-mono font-bold text-navy-600 mt-2 text-right">
                  — {personal.name}
                </p>
              </div>
            </motion.div>

            {/* Areas of Interest & Curiosity Chips */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ ...smoothTransition, delay: 0.2 }}
              className="p-5 sm:p-6 rounded-3xl bg-white border-2 border-navy-900 shadow-brutal-sm"
            >
              <div className="flex items-center gap-2 mb-3.5">
                <Heart className="w-4 h-4 text-coral fill-current shrink-0" />
                <h3 className="font-display font-bold text-sm sm:text-base text-navy-900">
                  Interests & Engineering Motivations
                </h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {personal.interests.map((interest, idx) => (
                  <motion.span
                    key={idx}
                    whileHover={{ scale: 1.04, y: -2 }}
                    whileTap={{ scale: 0.96 }}
                    className="px-3 py-1.5 rounded-xl bg-purple-soft text-navy-900 text-xs sm:text-sm font-semibold border-2 border-navy-900/30 hover:border-navy-900 hover:bg-lime-accent hover:shadow-brutal-sm transition-all cursor-default select-none"
                  >
                    {interest}
                  </motion.span>
                ))}
              </div>
            </motion.div>

          </div>

        </div>

      </div>
    </section>
  );
};
