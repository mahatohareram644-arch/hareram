import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FolderGit2, 
  Github, 
  BookOpen, 
  Sparkles, 
  ArrowUpRight, 
  Code2, 
  CheckCircle2 
} from 'lucide-react';
import { Project, ProjectCategory } from '../types/portfolio';
import { ProjectModal } from './ProjectModal';
import { smoothTransition } from '../utils/motion';

interface ProjectsProps {
  projects: Project[];
}

const filterOptions: ProjectCategory[] = ['All', 'Full Stack', 'Frontend', 'Tools & Systems'];

export const Projects: React.FC<ProjectsProps> = ({ projects }) => {
  const [activeFilter, setActiveFilter] = useState<ProjectCategory>('All');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const filteredProjects = activeFilter === 'All'
    ? projects
    : projects.filter(p => p.category === activeFilter);

  const getAccentStyles = (accent: Project['accent']) => {
    switch (accent) {
      case 'purple':
        return {
          badge: 'bg-purple-electric text-white border-navy-900',
          border: 'border-purple-electric',
          bgHeader: 'bg-purple-soft',
        };
      case 'coral':
        return {
          badge: 'bg-coral text-white border-navy-900',
          border: 'border-coral',
          bgHeader: 'bg-coral-soft',
        };
      case 'lime':
        return {
          badge: 'bg-lime-accent text-navy-900 border-navy-900',
          border: 'border-lime-accent',
          bgHeader: 'bg-lime-soft',
        };
      case 'navy':
      default:
        return {
          badge: 'bg-navy-900 text-white border-navy-900',
          border: 'border-navy-900',
          bgHeader: 'bg-cream-200',
        };
    }
  };

  return (
    <section id="projects" className="py-16 sm:py-24 bg-cream-50 relative overflow-hidden border-t-2 border-navy-900/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title & Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={smoothTransition}
          className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 sm:gap-6 mb-8 sm:mb-12"
        >
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white border-2 border-navy-900 shadow-brutal-sm text-xs font-mono font-bold uppercase tracking-wider text-purple-electric mb-3">
              <FolderGit2 className="w-3.5 h-3.5" />
              <span>03 / Works & Experiments</span>
            </div>
            <h2 className="font-display font-extrabold text-2xl sm:text-4xl lg:text-5xl text-navy-900 tracking-tight leading-tight">
              Featured{' '}
              <span className="font-editorial-serif font-normal italic text-purple-electric">Projects</span>{' '}
              & Systems.
            </h2>
          </div>
          <p className="text-xs sm:text-sm lg:text-base text-navy-600 max-w-md">
            Each project is crafted with high attention to UX details, accessible interactions, and clean software architecture.
          </p>
        </motion.div>

        {/* Category Filters - Horizontal swipe on mobile */}
        <div className="overflow-x-auto no-scrollbar -mx-4 px-4 sm:mx-0 sm:px-0 mb-8 sm:mb-12 pb-2">
          <div className="flex items-center gap-2 min-w-max">
            {filterOptions.map((filter) => {
              const count = filter === 'All' ? projects.length : projects.filter(p => p.category === filter).length;
              const isSelected = activeFilter === filter;
              return (
                <motion.button
                  key={filter}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setActiveFilter(filter)}
                  className={`inline-flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold border-2 transition-all ${
                    isSelected
                      ? 'bg-navy-900 text-white border-navy-900 shadow-brutal-sm -translate-y-0.5'
                      : 'bg-white text-navy-800 border-navy-900/20 hover:border-navy-900 hover:bg-cream-200'
                  }`}
                >
                  <span>{filter}</span>
                  <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-md ${isSelected ? 'bg-white/20 text-white' : 'bg-cream-300 text-navy-700'}`}>
                    {count}
                  </span>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Projects Gallery Grid */}
        <motion.div layout className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8">
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project, index) => {
              const accent = getAccentStyles(project.accent);
              const isWide = index === 0; // Make the first project an oversized hero showcase card

              return (
                <motion.article
                  layout
                  initial={{ opacity: 0, y: 24, scale: 0.96 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ type: 'spring', stiffness: 280, damping: 26 }}
                  key={project.id}
                  className={`group relative bg-white rounded-3xl border-3 border-navy-900 shadow-brutal hover:shadow-brutal-lg transition-all flex flex-col justify-between overflow-hidden ${
                    isWide ? 'lg:col-span-12' : 'lg:col-span-6'
                  }`}
                >
                  <div className={isWide ? 'grid grid-cols-1 lg:grid-cols-12 gap-0' : 'flex flex-col'}>
                    
                    {/* Visual Graphic Thumbnail Box */}
                    <div className={`relative p-5 sm:p-7 flex flex-col justify-between overflow-hidden border-b-2 lg:border-b-0 lg:border-r-2 border-navy-900 ${accent.bgHeader} ${
                      isWide ? 'lg:col-span-6 min-h-[260px] sm:min-h-[300px]' : 'min-h-[200px] sm:min-h-[220px]'
                    }`}>
                      
                      {/* Top Bar inside thumbnail */}
                      <div className="flex items-center justify-between gap-2 z-10">
                        <div className="flex items-center gap-1.5 sm:gap-2">
                          <span className={`px-2.5 py-0.5 rounded-md font-mono text-[10px] sm:text-[11px] font-bold uppercase tracking-wider border shadow-brutal-sm ${accent.badge}`}>
                            {project.category}
                          </span>
                          {project.featured && (
                            <span className="px-2 py-0.5 rounded-md font-mono text-[9px] sm:text-[10px] font-extrabold uppercase bg-lime-accent text-navy-900 border border-navy-900 flex items-center gap-1">
                              <Sparkles className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                              Featured
                            </span>
                          )}
                        </div>

                        {project.isPlaceholder && (
                          <span className="text-[10px] font-mono font-bold bg-white/90 text-navy-700 px-2 py-0.5 rounded border border-navy-900/30">
                            Customizable
                          </span>
                        )}
                      </div>

                      {/* Mockup / Abstract Tech Visual */}
                      <div className="my-4 sm:my-6 py-3 sm:py-4 flex flex-col items-center justify-center text-center relative z-10">
                        <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-2xl bg-white border-2 border-navy-900 shadow-brutal-sm flex items-center justify-center group-hover:scale-110 group-hover:rotate-2 transition-transform">
                          <Code2 className="w-6 h-6 sm:w-8 sm:h-8 text-navy-900" />
                        </div>
                        <h4 className="font-display font-bold text-base sm:text-lg text-navy-900 mt-2 sm:mt-3 px-2">
                          {project.title}
                        </h4>
                        <p className="text-[11px] sm:text-xs font-mono text-navy-600 mt-1 max-w-xs px-2 line-clamp-2">
                          {project.tagline}
                        </p>
                      </div>

                      {/* Metrics Pills at bottom of preview */}
                      {project.metrics && project.metrics.length > 0 && (
                        <div className="flex flex-wrap items-center gap-1.5 z-10">
                          {project.metrics.map((metric, mIdx) => (
                            <span
                              key={mIdx}
                              className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-white/90 text-navy-800 text-[10px] font-mono font-bold border border-navy-900/20"
                            >
                              <CheckCircle2 className="w-2.5 h-2.5 text-purple-electric shrink-0" />
                              <span className="truncate max-w-[150px]">{metric}</span>
                            </span>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Content Details Area */}
                    <div className={`p-5 sm:p-7 flex flex-col justify-between ${
                      isWide ? 'lg:col-span-6' : 'flex-1'
                    }`}>
                      <div>
                        <div className="flex items-center justify-between gap-4 mb-2">
                          <h3 className="font-display font-extrabold text-xl sm:text-2xl text-navy-900 group-hover:text-purple-electric transition-colors">
                            {project.title}
                          </h3>
                        </div>

                        <p className="text-xs sm:text-sm lg:text-base text-navy-700 leading-relaxed mb-5">
                          {project.description}
                        </p>

                        {/* Tech Stack Pills */}
                        <div className="flex flex-wrap gap-1.5 mb-5">
                          {project.tags.map((tag) => (
                            <span
                              key={tag}
                              className="px-2.5 py-0.5 rounded-lg bg-cream-200/80 text-navy-800 text-[11px] sm:text-xs font-mono font-bold border border-navy-900/20"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Bottom Action Buttons */}
                      <div className="pt-5 border-t-2 border-navy-900/10 flex flex-wrap items-center justify-between gap-2.5">
                        <div className="flex items-center gap-2">
                          {/* Case Study Modal Trigger */}
                          {project.caseStudy && (
                            <motion.button
                              whileHover={{ scale: 1.02 }}
                              whileTap={{ scale: 0.96 }}
                              onClick={() => setSelectedProject(project)}
                              className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 bg-cream-100 hover:bg-cream-200 text-navy-900 text-xs font-bold rounded-xl border-2 border-navy-900 shadow-brutal-sm transition-all"
                            >
                              <BookOpen className="w-3.5 h-3.5 text-purple-electric shrink-0" />
                              <span>Read Case Study</span>
                            </motion.button>
                          )}

                          {/* GitHub Link */}
                          {project.links.githubUrl && (
                            <motion.a
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              href={project.links.githubUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="min-w-[40px] min-h-[40px] flex items-center justify-center p-2 bg-white hover:bg-cream-200 text-navy-900 rounded-xl border-2 border-navy-900 shadow-brutal-sm transition-all"
                              aria-label="GitHub Repository"
                            >
                              <Github className="w-4 h-4" />
                            </motion.a>
                          )}
                        </div>

                        {/* Live Demo Link */}
                        {project.links.liveUrl ? (
                          <motion.a
                            whileHover={{ scale: 1.03 }}
                            whileTap={{ scale: 0.96 }}
                            href={project.links.liveUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="min-h-[40px] inline-flex items-center gap-1.5 px-4 py-2 bg-lime-accent hover:bg-lime-hover text-navy-900 text-xs font-bold rounded-xl border-2 border-navy-900 shadow-brutal-sm transition-all"
                          >
                            <span>Live Demo</span>
                            <ArrowUpRight className="w-3.5 h-3.5" />
                          </motion.a>
                        ) : (
                          <span className="text-[11px] font-mono text-navy-500 italic">
                            Demo in portfolio.ts
                          </span>
                        )}
                      </div>

                    </div>

                  </div>
                </motion.article>
              );
            })}
          </AnimatePresence>
        </motion.div>

        {/* Centralized config note */}
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-10 sm:mt-14 p-4 sm:p-5 rounded-2xl bg-white border-2 border-navy-900 shadow-brutal-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
        >
          <div className="flex items-center gap-3">
            <span className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-purple-soft text-purple-electric flex items-center justify-center border border-navy-900 font-bold shrink-0">
              ✦
            </span>
            <div>
              <p className="font-bold text-navy-900 text-xs sm:text-sm">Want to showcase more or different projects?</p>
              <p className="text-navy-600 text-[11px] sm:text-xs">Update the <code className="font-mono bg-cream-200 px-1 py-0.5 rounded">projects</code> array in <code className="font-mono font-bold">src/data/portfolio.ts</code>.</p>
            </div>
          </div>
          <span className="font-mono text-[10px] sm:text-[11px] text-navy-500 shrink-0">Live demos and GitHub links update instantly</span>
        </motion.div>

      </div>

      {/* Case Study Modal */}
      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />
    </section>
  );
};
