import { PortfolioData } from '../types/portfolio';

/**
 * ============================================================================
 * CENTRAL PORTFOLIO CONFIGURATION
 * ============================================================================
 * Update this single file to customize all personal info, skills, projects,
 * journey items, and contact preferences without touching any UI component!
 */

export const portfolioData: PortfolioData = {
  personal: {
    // Brother's full name:
    name: "Hare Ram Mahato",
    pronouns: "he/him",
    
    // Replace with his actual role / title (e.g., "Full-Stack Software Engineer", "Frontend Developer", "UI/UX & Web Developer"):
    role: "Full-Stack & Creative Web Developer",
    
    // Expressive eyebrow badge shown above the main title:
    eyebrow: "Creative Frontend & Web Developer",
    
    // Punchy headline or tagline:
    tagline: "I Build Things for the Web.",
    
    // Short hero introduction (1-2 sentences):
    shortBio: "Crafting expressive, high-performance web applications with thoughtful user experiences, modern code architectures, and a keen eye for playful interaction.",
    
    // Detailed bio paragraphs for the About Me section:
    aboutParagraphs: [
      "I am a developer who believes web software should not only be fast and reliable, but also genuinely delightful to use. My focus centers on building responsive, accessible web interfaces that bridge engineering precision with contemporary creative design.",
      "Whether architecting robust component libraries, optimizing client-side performance, or integrating real-time backends, I bring curiosity, rigor, and craft to every layer of the stack.",
      "When I am not writing code, you can find me studying design systems, exploring typography and generative art, or experimenting with new open-source technologies."
    ],
    
    personalMotto: "Great software lives at the intersection of rigorous code and expressive design.",
    
    location: "Global / Remote & Local",
    
    availability: {
      status: "Available",
      label: "Open for freelance & full-time roles",
      sublabel: "Available for new projects & collaborations"
    },
    
    // Social & Contact links:
    email: "hareram.mahato@example.com", // Replace with his actual email
    github: "https://github.com",           // Replace with his actual GitHub URL
    linkedin: "https://linkedin.com",       // Replace with his actual LinkedIn URL
    twitter: "https://x.com",               // Optional: Replace or remove
    resumeUrl: "#",                         // Link to his PDF resume or leave as "#"
    avatarUrl: "",                          // Leave empty to display the built-in illustrated creative avatar
    
    // Key facts & highlights (shown in the About section):
    quickFacts: [
      { label: "Focus", value: "Frontend & Full Stack", highlight: true },
      { label: "Core Stack", value: "React • TypeScript • Tailwind" },
      { label: "Philosophy", value: "Accessible & Performant by default" },
      { label: "Collaboration", value: "Remote-Ready Worldwide" },
    ],
    
    interests: [
      "Design Systems",
      "Interactive WebGL / Canvas",
      "Modern Web Architecture",
      "Micro-Interactions",
      "Developer Tooling"
    ],
    
    // Contact Form Configuration:
    contactConfig: {
      /**
       * Choose how the contact form behaves:
       * - 'mailto': Direct fallback that opens user's email client with pre-filled message (zero setup required!)
       * - 'formspree': Sends to Formspree endpoint (set formspreeId below)
       * - 'web3forms': Sends via Web3Forms API (set web3formsAccessKey below)
       */
      mode: 'mailto',
      
      // If using Formspree (free signup at https://formspree.io):
      // formspreeId: "your-formspree-id",
      
      // If using Web3Forms (free signup at https://web3forms.com):
      // web3formsAccessKey: "your-access-key-here",
      
      recipientEmail: "hareram.mahato@example.com",
      noticeText: "Currently configured with direct client-side email dispatch. You can seamlessly switch to Formspree or Web3Forms in src/data/portfolio.ts."
    }
  },

  /**
   * ==========================================================================
   * SKILLS & TOOLS
   * Note: Only real skills are listed here. Easy to add/remove.
   * ==========================================================================
   */
  skills: [
    // Programming Languages
    { name: "TypeScript", category: "languages", level: "Core" },
    { name: "JavaScript (ESNext)", category: "languages", level: "Core" },
    { name: "HTML5 / Semantic Web", category: "languages", level: "Core" },
    { name: "CSS3 / Modern Layouts", category: "languages", level: "Core" },
    { name: "SQL", category: "languages", level: "Working Knowledge" },
    { name: "Python", category: "languages", level: "Working Knowledge" },

    // Frontend Development
    { name: "React", category: "frontend", level: "Core" },
    { name: "Next.js", category: "frontend", level: "Advanced" },
    { name: "Tailwind CSS", category: "frontend", level: "Core" },
    { name: "Motion (Framer Motion)", category: "frontend", level: "Advanced" },
    { name: "State Management (Zustand/Redux)", category: "frontend", level: "Advanced" },
    { name: "Responsive & Accessible UI (a11y)", category: "frontend", level: "Core" },

    // Backend Development
    { name: "Node.js", category: "backend", level: "Advanced" },
    { name: "Express.js", category: "backend", level: "Advanced" },
    { name: "RESTful API Design", category: "backend", level: "Core" },
    { name: "PostgreSQL / SQLite", category: "backend", level: "Working Knowledge" },
    { name: "Authentication & JWT", category: "backend", level: "Working Knowledge" },

    // Developer Tools & Workflow
    { name: "Git & GitHub", category: "tools", level: "Core" },
    { name: "Vite / Modern Bundlers", category: "tools", level: "Core" },
    { name: "npm / pnpm / yarn", category: "tools", level: "Core" },
    { name: "VS Code / IDE Workflows", category: "tools", level: "Core" },
    { name: "Vercel / Netlify Deployments", category: "tools", level: "Advanced" },

    // Design Tools
    { name: "Figma", category: "design", level: "Advanced" },
    { name: "Design Systems & Tokens", category: "design", level: "Advanced" },
    { name: "Wireframing & Prototyping", category: "design", level: "Working Knowledge" },
  ],

  /**
   * ==========================================================================
   * FEATURED PROJECTS
   * Initial projects with clean placeholder tags. Replace with your brother's
   * actual projects, live links, and GitHub repositories.
   * ==========================================================================
   */
  projects: [
    {
      id: "project-1",
      title: "Interactive Workspace Dashboard",
      tagline: "High-performance collaborative analytics and team productivity hub.",
      description: "A modern web dashboard built with React and TypeScript featuring live data visualizations, customizable widget layouts, dynamic theme palettes, and keyboard-first navigation.",
      category: "Full Stack",
      featured: true,
      accent: "purple",
      tags: ["React", "TypeScript", "Tailwind CSS", "Recharts", "Node.js"],
      metrics: ["Sub-50ms render latency", "WCAG 2.1 AA Compliant", "Fully responsive"],
      links: {
        liveUrl: null, // Set to real URL when deployed (e.g. "https://my-dashboard.example.com")
        githubUrl: "https://github.com", // Set to real repo
        caseStudyUrl: "#"
      },
      caseStudy: {
        challenge: "Creating a rich analytics interface that remains responsive with large streaming datasets while preserving an intuitive editorial design language.",
        solution: "Implemented virtualized component lists, optimized canvas rendering for charts, and built a declarative widget system powered by modern React state primitives.",
        keyFeatures: [
          "Interactive drag-and-drop dashboard modularity",
          "Real-time metric updates with optimistic UI updates",
          "Comprehensive dark/warm theme support",
          "Exportable data summaries in CSV and SVG format"
        ],
        architectureNotes: [
          "Modular component tree with zero unnecessary re-renders",
          "TypeScript strict type safety across all chart schemas",
          "Accessible ARIA landmarks and full keyboard shortcut palette"
        ]
      },
      isPlaceholder: true
    },
    {
      id: "project-2",
      title: "Editorial Design System & Component Library",
      tagline: "An accessible, themeable UI library for contemporary digital publishing.",
      description: "A standalone design token library and collection of accessible, animated React components engineered for speed, high contrast readability, and expressive brand storytelling.",
      category: "Frontend",
      featured: true,
      accent: "coral",
      tags: ["React", "Tailwind CSS", "Framer Motion", "Storybook", "TypeScript"],
      metrics: ["30+ Reusable Components", "100% Lighthouse Score", "Zero CSS runtime"],
      links: {
        liveUrl: null,
        githubUrl: "https://github.com",
        caseStudyUrl: "#"
      },
      caseStudy: {
        challenge: "Bridging the gap between strict design tokens and creative editorial layouts that require asymmetric compositions without compromising responsive behavior.",
        solution: "Crafted CSS custom property primitives with fluid typography scales and animated Motion layout transitions.",
        keyFeatures: [
          "Custom fluid typography calculations based on viewport clamp",
          "Pre-built cards, badges, and interactive editorial timelines",
          "Automated visual regression testing",
          "Reduced-motion friendly transitions"
        ]
      },
      isPlaceholder: true
    },
    {
      id: "project-3",
      title: "Real-Time Collaborative Markdown Canvas",
      tagline: "Distraction-free rich text editor with instant synchronization.",
      description: "A lightweight, browser-based markdown editor with side-by-side synchronized preview, custom syntax highlighting, LaTeX math formatting, and local persistence.",
      category: "Tools & Systems",
      featured: false,
      accent: "lime",
      tags: ["TypeScript", "Web Workers", "IndexedDB", "Tailwind CSS"],
      metrics: ["Instant offline load", "Zero telemetry", "Local-first storage"],
      links: {
        liveUrl: null,
        githubUrl: "https://github.com",
        caseStudyUrl: "#"
      },
      caseStudy: {
        challenge: "Parsing large markdown files and rendering complex formatting in real time without dropping framerates on lower-powered devices.",
        solution: "Offloaded markdown parsing and AST transformations to a dedicated Web Worker, updating DOM trees via diffing.",
        keyFeatures: [
          "Instant offline support with IndexedDB automatic backup",
          "Custom math equation renderer and syntax highlighters",
          "Clean distraction-free zen writing mode"
        ]
      },
      isPlaceholder: true
    },
    {
      id: "project-4",
      title: "Smart Recipe & Nutrition Planning Platform",
      tagline: "Intelligent pantry management with ingredient substitution algorithms.",
      description: "A web platform that helps users organize weekly meal plans, track dietary goals, and dynamically scale recipe ingredients with automated grocery list compilation.",
      category: "Full Stack",
      featured: false,
      accent: "navy",
      tags: ["React", "Node.js", "Express", "PostgreSQL", "REST API"],
      metrics: ["Fast dynamic search", "Clean REST API", "Print-optimized layouts"],
      links: {
        liveUrl: null,
        githubUrl: "https://github.com",
        caseStudyUrl: "#"
      },
      isPlaceholder: true
    }
  ],

  /**
   * ==========================================================================
   * EXPERIENCE & JOURNEY
   * Timeline of milestones, education, and development experience.
   * Update with his actual degrees, internships, or milestones.
   * ==========================================================================
   */
  journey: [
    {
      id: "journey-1",
      type: "experience",
      period: "2023 — Present",
      title: "Frontend Developer & Web Engineering",
      organization: "[Company / Organization or Independent]",
      location: "Remote / Hybrid",
      description: "Building responsive, modern web applications, optimizing frontend performance, and collaborating on product features from ideation to production deployment.",
      highlights: [
        "Architecting clean, modular TypeScript and React components with high test coverage",
        "Translating UX design wireframes into pixel-perfect, accessible web interfaces",
        "Improving Core Web Vitals and load performance across key landing pages"
      ],
      tags: ["React", "TypeScript", "Tailwind CSS", "Git"],
      isPlaceholder: true
    },
    {
      id: "journey-2",
      type: "education",
      period: "2020 — 2024",
      title: "Bachelor's Degree in Computer Science / Engineering",
      organization: "[University / College Name]",
      location: "[City, Country]",
      description: "Rigorous coursework in computer science fundamentals, data structures, algorithms, database management systems, web technologies, and software engineering methodologies.",
      highlights: [
        "Focused study in Web Technologies and Distributed Systems",
        "Completed capstone engineering project with honors",
        "Active member of developer and technology student clubs"
      ],
      tags: ["Data Structures", "Algorithms", "Web Architecture", "Database Systems"],
      isPlaceholder: true
    },
    {
      id: "journey-3",
      type: "milestone",
      period: "2022 — 2023",
      title: "Software Engineering Intern / Web Development Fellow",
      organization: "[Tech Company or Organization]",
      location: "[Location or Remote]",
      description: "Collaborated in an agile team environment to develop customer-facing UI features, write unit tests, and participate in code reviews.",
      highlights: [
        "Implemented interactive search and filtering modules",
        "Refactored legacy styles to utility-first modern CSS",
        "Authored developer documentation for onboarding new contributors"
      ],
      tags: ["JavaScript", "HTML/CSS", "Team Collaboration", "Agile/Scrum"],
      isPlaceholder: true
    }
  ]
};

