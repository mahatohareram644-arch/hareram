import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { portfolioData } from './data/portfolio';
import { useActiveSection } from './hooks/useActiveSection';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Skills } from './components/Skills';
import { Projects } from './components/Projects';
import { Journey } from './components/Journey';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { ArrowUp } from 'lucide-react';

export const App: React.FC = () => {
  const sectionIds = ['home', 'about', 'skills', 'projects', 'journey', 'contact'];
  const activeSection = useActiveSection(sectionIds, 120);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 380);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  return (
    <div className="min-h-screen bg-cream-100 text-navy-900 flex flex-col font-sans selection:bg-purple-electric selection:text-white overflow-x-hidden">
      {/* Top Navigation */}
      <Navbar personal={portfolioData.personal} activeSection={activeSection} />

      {/* Main Content Sections */}
      <main className="flex-1">
        <Hero personal={portfolioData.personal} />
        <About personal={portfolioData.personal} />
        <Skills skills={portfolioData.skills} />
        <Projects projects={portfolioData.projects} />
        <Journey journey={portfolioData.journey} />
        <Contact personal={portfolioData.personal} />
      </main>

      {/* Global Footer */}
      <Footer personal={portfolioData.personal} />

      {/* Floating Return to Top Button */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 15 }}
            transition={{ type: 'spring', stiffness: 350, damping: 25 }}
            whileHover={{ scale: 1.08, y: -2 }}
            whileTap={{ scale: 0.92 }}
            onClick={scrollToTop}
            aria-label="Scroll back to top"
            className="fixed bottom-5 right-5 sm:bottom-6 sm:right-6 z-30 min-w-[44px] min-h-[44px] flex items-center justify-center p-3 rounded-2xl bg-white text-navy-900 border-2 border-navy-900 shadow-brutal hover:shadow-brutal-lg hover:bg-lime-accent transition-all focus:outline-none"
          >
            <ArrowUp className="w-5 h-5 text-navy-900" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
};

export default App;
