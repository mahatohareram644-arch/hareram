/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        cream: {
          50: '#FDFCF9',
          100: '#F8F7F2', // Warm off-white background
          200: '#EFECE1',
          300: '#E2DEC9',
        },
        navy: {
          900: '#172033', // Deep navy text
          800: '#1E2C44',
          700: '#2A3C5B',
          600: '#3D5278',
          100: '#E9EEF7',
        },
        purple: {
          electric: '#7957FF', // Electric purple
          hover: '#6642F5',
          light: '#ECE6FE',
          soft: '#F3F0FC', // Soft lavender
        },
        coral: {
          DEFAULT: '#FF725E', // Vibrant coral
          hover: '#F05F4A',
          soft: '#FFF0ED',
          light: '#FFE4E0',
        },
        lime: {
          accent: '#D9F36A', // Fresh lime accent
          hover: '#C8E64F',
          soft: '#F5FDE3',
        },
      },
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'system-ui', '-apple-system', 'sans-serif'],
        display: ['"Space Grotesk"', '"Plus Jakarta Sans"', 'sans-serif'],
        serif: ['"Newsreader"', 'Georgia', 'serif'],
      },
      boxShadow: {
        'brutal-sm': '2px 2px 0px #172033',
        'brutal': '4px 4px 0px #172033',
        'brutal-lg': '6px 6px 0px #172033',
        'brutal-purple': '4px 4px 0px #7957FF',
        'brutal-coral': '4px 4px 0px #FF725E',
        'brutal-lime': '4px 4px 0px #172033',
        'soft-lift': '0 12px 30px -10px rgba(23, 32, 51, 0.08)',
        'soft-hover': '0 20px 40px -15px rgba(121, 87, 255, 0.15)',
      },
      animation: {
        'float-slow': 'float 6s ease-in-out infinite',
        'float-reverse': 'floatReverse 7s ease-in-out infinite',
        'pulse-subtle': 'pulseSubtle 3s ease-in-out infinite',
        'spin-slow': 'spin 18s linear infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-12px)' },
        },
        floatReverse: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(12px)' },
        },
        pulseSubtle: {
          '0%, 100%': { opacity: '1', transform: 'scale(1)' },
          '50%': { opacity: '0.85', transform: 'scale(1.02)' },
        },
      },
    },
  },
  plugins: [],
}

